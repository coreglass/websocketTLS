package com.example.client;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.Session;
import java.io.IOException;
import java.net.URI;

@WebServlet("/sendWebSocketMessage")
public class WebSocketMessageSenderServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String message = request.getParameter("message"); // 从 HTTP 请求中获取消息

        if (message == null) {
            WebSocketClient webSocketClient = new WebSocketClient();
            try {
                // 替换成实际的 WebSocket 服务器地址
                String serverEndpoint = "wss://localhost:8443/websocket";
                javax.websocket.WebSocketContainer container = javax.websocket.ContainerProvider.getWebSocketContainer();
                Session session = container.connectToServer(webSocketClient, new URI(serverEndpoint));
                webSocketClient.sendMessage(message); // 发送消息到 WebSocket 服务器
                session.close();
                response.getWriter().write("Message sent successfully.");
            } catch (Exception e) {
                e.printStackTrace();
                response.getWriter().write("Failed to send message: " + e.getMessage());
            }
        } else {
            response.getWriter().write("Message parameter is missing.");
        }
    }
}

